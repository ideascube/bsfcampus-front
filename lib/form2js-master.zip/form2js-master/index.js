module.exports.form2js = require('./src/form2js');

module.exports.js2form = require('./src/js2form');