// Make a copy of this file called config.js and customize configuration.

define(function(){ 

	var config = {};

	config.server_type = 'local';

	/*
	Uncomment the line below if the server is on a custom port.
	Default is 5001 is server_type == 'local', 5000 otherwise.
	*/
	var server_port = 5001;

	return config;

})