define(
    [
        'jquery',
        'underscore',
        'backbone',
        'jqueryserialize',
        'app/config',

        'pods/user/models/current',
        'text!pods/user/profile/pages/templates/password.html',

        'less!pods/user/profile/pages/styles/password'
    ],
    function($, _, Backbone, $serialize, Config,
             currentUser, accountTemplate
    ) {

        return Backbone.View.extend({

            tagName: 'div',

            id: 'user-profile-password-container',

            template: _.template(accountTemplate),

            events: {
                'click #save_modification': 'saveModifications'
            },

            render: function() {
                var html = this.template({config: Config});
                this.$el.html(html);

                return this;
            },

            saveModifications: function() {
                console.log("save user profile modifications");
                var formData = this.$el.find('form').serializeJSON();
                var $saveButton = this.$el.find('button.save_modification');
                $saveButton.addClass('disabled');
                var $passwordSaveResult = this.$el.find('#password-save-result');
                $passwordSaveResult.removeClass('success');
                $passwordSaveResult.removeClass('fail');
                $.ajax({
                    type: 'PATCH',
                    contentType: 'application/json',
                    url: Config.constants.serverGateway + "/users/current",
                    data: formData,
                    dataType: 'json'
                }).done(function(result){
                    console.log(JSON.stringify(result));
                    $passwordSaveResult.html(Config.stringsDict.USER.PROFILE.PASSWORD.SAVE_SUCCESS_MESSAGE);
                    $passwordSaveResult.addClass('success');
                    $saveButton.removeClass('disabled');
                }).fail(function(error){
                    console.log("Could not post user modifications", error);
                    $passwordSaveResult.html(Config.stringsDict.USER.PROFILE.PASSWORD.SAVE_FAIL_MESSAGE);
                    $passwordSaveResult.addClass('fail');
                    $saveButton.removeClass('disabled');
                });
            }

        });

    }
);
